<div align="center">
<img src="https://i.imgur.com/ir3vFwk.png" width=100px>
<br>
<h1>Alertpix.py</h1>

![OS](https://img.shields.io/badge/OS-linux%20%7C%20windows-blue??style=flat&logo=Linux&logoColor=b0c0c0&labelColor=363D44)
<br>
<i>Uma biblioteca python para facilitar o uso da API do AlertPix</i>
<br>

